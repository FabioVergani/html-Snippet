A Pen created at CodePen.io. You can find this one at http://codepen.io/fabiovergani/pen/zwYwdW.

 Table header visible when table data rows  scrolls. 
Supports rowspan and colspan. 